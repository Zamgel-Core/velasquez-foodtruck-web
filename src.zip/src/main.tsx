import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { registerPwa } from './pwa/registerPwa.ts';
import { AppUpdateNotice } from './components/AppUpdateNotice.tsx';

registerPwa();

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <>
    <App />
    <AppUpdateNotice />
  </>
  </StrictMode>,
);

// 📍 Ruta: src/features/admin/app-mode/AppModePage.tsx

import React from "react";
import { motion } from "motion/react";
import {
  AlertTriangle,
  ArrowLeft,
  CheckCircle2,
  Clipboard,
  Clock3,
  ExternalLink,
  ListChecks,
  MonitorSmartphone,
  RefreshCw,
  ShieldCheck,
  Smartphone,
  TabletSmartphone,
  Wifi,
} from "lucide-react";
import AdminTopbar from "../components/AdminTopbar";
import {
  applyAppUpdate,
  checkAppVersion,
  getLastVersionCheck,
  type AppVersionInfo,
  type AppVersionStatus,
} from "../../../pwa/appVersion";

const installSteps = [
  {
    titleEs: "Abrir Safari en el iPad",
    titleEn: "Open Safari on the iPad",
    descriptionEs:
      "Entra a velasquezfoodtruck.com/admin/pos o al portal admin desde Safari. En iPhone/iPad es importante usar Safari para agregar la app a la pantalla de inicio.",
    descriptionEn:
      "Go to velasquezfoodtruck.com/admin/pos or the admin portal from Safari. On iPhone/iPad, Safari is required to add the app to the home screen.",
  },
  {
    titleEs: "Tocar Compartir",
    titleEn: "Tap Share",
    descriptionEs:
      "Presiona el botón de compartir de Safari. Normalmente aparece en la barra superior o inferior del navegador.",
    descriptionEn:
      "Tap Safari's Share button. It usually appears in the top or bottom browser bar.",
  },
  {
    titleEs: "Agregar a pantalla de inicio",
    titleEn: "Add to Home Screen",
    descriptionEs:
      "Selecciona Agregar a pantalla de inicio, confirma el nombre Velasquez y toca Agregar.",
    descriptionEn:
      "Choose Add to Home Screen, confirm the Velasquez name, and tap Add.",
  },
  {
    titleEs: "Abrir como app",
    titleEn: "Open as an app",
    descriptionEs:
      "El ícono quedará en el iPad. Al abrirlo se verá más limpio, como aplicación, ideal para usar POS y órdenes.",
    descriptionEn:
      "The icon will stay on the iPad. When opened, it looks cleaner, like an app, ideal for POS and orders.",
  },
];

const quickLinks = [
  { labelEs: "Abrir POS", labelEn: "Open POS", href: "/admin/pos" },
  { labelEs: "Abrir Órdenes", labelEn: "Open Orders", href: "/admin/orders" },
  { labelEs: "Abrir Portal Admin", labelEn: "Open Admin Portal", href: "/admin" },
];

function StatusPill({ enabled, label }: { enabled: boolean; label: string }) {
  return (
    <div
      className={`inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-black uppercase tracking-[0.18em] ${
        enabled
          ? "border-green-500/30 bg-green-500/10 text-green-200"
          : "border-red-500/30 bg-red-500/10 text-red-200"
      }`}
    >
      <CheckCircle2 className="h-3.5 w-3.5" />
      {label}
    </div>
  );
}

function formatDateTime(value?: string | null) {
  if (!value) return "Sin registro / No record";

  try {
    return new Intl.DateTimeFormat("es-US", {
      dateStyle: "medium",
      timeStyle: "short",
    }).format(new Date(value));
  } catch {
    return value;
  }
}

function VersionCard({ title, version }: { title: string; version?: AppVersionInfo | null }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/[0.035] p-3">
      <p className="text-[10px] font-black uppercase tracking-[0.18em] text-white/35">
        {title}
      </p>
      <p className="mt-1 text-2xl font-black text-white">
        {version?.version ?? "—"}
      </p>
      <p className="text-xs font-semibold text-white/40">
        Build {version?.build ?? "—"}
      </p>
      {version?.label ? (
        <p className="mt-2 text-xs font-bold text-red-100/75">{version.label}</p>
      ) : null}
    </div>
  );
}

export default function AppModePage() {
  const [copied, setCopied] = React.useState("");
  const [isStandalone, setIsStandalone] = React.useState(false);
  const [supportsServiceWorker, setSupportsServiceWorker] = React.useState(false);
  const [supportsManifest, setSupportsManifest] = React.useState(false);
  const [versionStatus, setVersionStatus] = React.useState<AppVersionStatus | null>(null);
  const [versionError, setVersionError] = React.useState("");
  const [checkingVersion, setCheckingVersion] = React.useState(false);
  const [updatingApp, setUpdatingApp] = React.useState(false);
  const [lastCheckedAt, setLastCheckedAt] = React.useState<string | null>(null);

  const refreshVersionStatus = React.useCallback(async () => {
    try {
      setCheckingVersion(true);
      setVersionError("");
      const status = await checkAppVersion();
      setVersionStatus(status);
      setLastCheckedAt(status.lastCheckedAt);
    } catch (error) {
      console.warn("No se pudo revisar la versión de la app:", error);
      setLastCheckedAt(getLastVersionCheck());
      setVersionError(
        "No se pudo consultar version.json. Verifica que el archivo exista en public/version.json.",
      );
    } finally {
      setCheckingVersion(false);
    }
  }, []);

  React.useEffect(() => {
    const standalone =
      window.matchMedia?.("(display-mode: standalone)")?.matches ||
      Boolean((window.navigator as Navigator & { standalone?: boolean }).standalone);

    setIsStandalone(Boolean(standalone));
    setSupportsServiceWorker("serviceWorker" in navigator);
    setSupportsManifest(Boolean(document.querySelector('link[rel="manifest"]')));
    setLastCheckedAt(getLastVersionCheck());
    refreshVersionStatus();
  }, [refreshVersionStatus]);

  const handleApplyUpdate = async () => {
    if (!versionStatus?.current) return;

    try {
      setUpdatingApp(true);
      await applyAppUpdate(versionStatus.current);
    } catch (error) {
      console.warn("No se pudo aplicar la actualización:", error);
      window.location.reload();
    } finally {
      setUpdatingApp(false);
    }
  };

  const copyUrl = async (path: string) => {
    const origin = window.location.origin;
    const url = `${origin}${path}`;

    try {
      await navigator.clipboard.writeText(url);
      setCopied(path);
      window.setTimeout(() => setCopied(""), 1800);
    } catch {
      setCopied("");
      window.prompt("Copia este enlace:", url);
    }
  };

  const hasUpdate = Boolean(versionStatus?.hasUpdate);
  const changes = versionStatus?.current?.changes ?? [];

  return (
    <main className="min-h-screen bg-[#050505] text-white">
      <AdminTopbar />

      <section className="mx-auto w-full max-w-6xl px-4 pb-10">
        <div className="mb-6 flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <a
              href="/admin"
              className="mb-4 inline-flex items-center gap-2 text-sm font-bold text-white/50 transition hover:text-red-200"
            >
              <ArrowLeft className="h-4 w-4" />
              Volver al portal / Back to portal
            </a>

            <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-red-500/30 bg-red-500/10 px-4 py-2 text-xs font-bold uppercase tracking-[0.25em] text-red-200">
              <MonitorSmartphone className="h-4 w-4" />
              Modo APP / App Mode
            </div>

            <h1 className="text-3xl font-black tracking-tight sm:text-5xl">
              Instalar Velasquez como App
            </h1>

            <p className="mt-3 max-w-3xl text-sm font-semibold leading-relaxed text-white/55 sm:text-base">
              Guía rápida para usar el POS y el portal admin desde el iPad como si fuera una app instalada. / Quick guide to use the POS and admin portal from the iPad like an installed app.
            </p>
          </div>

          <button
            type="button"
            onClick={refreshVersionStatus}
            className="inline-flex items-center justify-center gap-2 rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm font-black text-white/70 transition hover:border-red-500/40 hover:bg-red-500/10 hover:text-red-100"
          >
            <RefreshCw className={`h-4 w-4 ${checkingVersion ? "animate-spin" : ""}`} />
            Revisar versión
          </button>
        </div>

        <div className="grid gap-6 lg:grid-cols-[0.95fr_1.05fr]">
          <motion.section
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            className="rounded-3xl border border-red-500/20 bg-red-500/[0.06] p-5 shadow-2xl shadow-red-950/20"
          >
            <div className="mb-5 flex items-start gap-3">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl border border-red-500/30 bg-red-500/15 text-red-200">
                <TabletSmartphone className="h-6 w-6" />
              </div>
              <div>
                <h2 className="text-xl font-black">Estado PWA / PWA Status</h2>
                <p className="mt-1 text-sm font-semibold leading-relaxed text-white/50">
                  Validación básica del navegador actual y estado de actualización. / Browser validation and update status.
                </p>
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              <StatusPill enabled={supportsManifest} label="Manifest" />
              <StatusPill enabled={supportsServiceWorker} label="Service Worker" />
              <StatusPill enabled={isStandalone} label={isStandalone ? "App instalada" : "Navegador"} />
              <StatusPill enabled={!hasUpdate} label={hasUpdate ? "Actualizar" : "Versión OK"} />
            </div>

            <div className="mt-5 rounded-2xl border border-red-500/20 bg-black/35 p-4">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <p className="text-sm font-black text-white">
                    Centro de versión / Version Center
                  </p>
                  <p className="mt-1 text-xs font-semibold leading-relaxed text-white/45">
                    Compara la versión instalada contra <span className="font-black text-red-200">version.json</span>. / Compares the installed version against <span className="font-black text-red-200">version.json</span>.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={refreshVersionStatus}
                  disabled={checkingVersion}
                  className="inline-flex items-center justify-center gap-2 rounded-2xl border border-white/10 bg-white/5 px-4 py-2.5 text-xs font-black text-white/70 transition hover:border-red-500/40 hover:bg-red-500/10 hover:text-red-100 disabled:cursor-not-allowed disabled:opacity-60"
                >
                  <RefreshCw className={`h-3.5 w-3.5 ${checkingVersion ? "animate-spin" : ""}`} />
                  Revisar / Check
                </button>
              </div>

              <div className="mt-4 grid gap-3 sm:grid-cols-2">
                <VersionCard title="Instalada / Installed" version={versionStatus?.installed} />
                <VersionCard title="Última / Latest" version={versionStatus?.current} />
              </div>

              <div className="mt-3 rounded-2xl border border-white/10 bg-white/[0.035] p-3">
                <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.18em] text-white/35">
                  <Clock3 className="h-3.5 w-3.5" />
                  Última comprobación / Last check
                </div>
                <p className="mt-1 text-sm font-black text-white">
                  {formatDateTime(lastCheckedAt)}
                </p>
              </div>

              {versionError ? (
                <p className="mt-3 rounded-2xl border border-red-500/20 bg-red-500/10 p-3 text-xs font-bold leading-relaxed text-red-100">
                  {versionError}
                </p>
              ) : null}

              {hasUpdate ? (
                <div className="mt-4 rounded-2xl border border-yellow-500/25 bg-yellow-500/10 p-4">
                  <div className="flex items-start gap-3">
                    <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-yellow-200" />
                    <div>
                      <p className="text-sm font-black uppercase tracking-[0.18em] text-yellow-100">
                        Actualización disponible / Update available
                      </p>
                      <p className="mt-2 text-xs font-semibold leading-relaxed text-white/65">
                        Hay una versión nueva lista para instalar. / A new version is ready to install.
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={handleApplyUpdate}
                    disabled={updatingApp}
                    className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-red-600 px-4 py-3 text-sm font-black text-white shadow-lg shadow-red-600/25 transition hover:bg-red-700 disabled:cursor-not-allowed disabled:opacity-60"
                  >
                    <RefreshCw className={`h-4 w-4 ${updatingApp ? "animate-spin" : ""}`} />
                    Actualizar ahora / Update now
                  </button>
                </div>
              ) : (
                <div className="mt-4 rounded-2xl border border-green-500/20 bg-green-500/10 p-4">
                  <div className="flex items-start gap-3">
                    <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-green-200" />
                    <div>
                      <p className="text-sm font-black uppercase tracking-[0.18em] text-green-100">
                        App actualizada / App up to date
                      </p>
                      <p className="mt-2 text-xs font-semibold leading-relaxed text-white/65">
                        No hay nuevas versiones disponibles. / No new versions are available.
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {changes.length > 0 ? (
                <div className="mt-4 rounded-2xl border border-white/10 bg-black/35 p-4">
                  <div className="mb-3 flex items-center gap-2 text-xs font-black uppercase tracking-[0.18em] text-red-100">
                    <ListChecks className="h-4 w-4" />
                    Novedades / Changelog
                  </div>
                  <ul className="space-y-2 text-xs font-semibold leading-relaxed text-white/60">
                    {changes.map((change) => (
                      <li key={change} className="flex gap-2">
                        <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-red-400" />
                        <span>{change}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              ) : null}
            </div>

            <div className="mt-5 rounded-2xl border border-white/10 bg-black/35 p-4 text-sm font-semibold leading-relaxed text-white/55">
              <p className="font-black text-white">Nota importante / Important note</p>
              <p className="mt-2">
                En iPad no aparece un botón automático de instalación como en Android. El cliente debe usar Safari y elegir Compartir → Agregar a pantalla de inicio. / On iPad, there is no automatic install button like Android. The customer must use Safari and choose Share → Add to Home Screen.
              </p>
            </div>
          </motion.section>

          <motion.section
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.05 }}
            className="rounded-3xl border border-white/10 bg-white/[0.035] p-5 shadow-2xl shadow-black/30"
          >
            <div className="mb-5 flex items-start gap-3">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl border border-red-500/30 bg-red-500/15 text-red-200">
                <Smartphone className="h-6 w-6" />
              </div>
              <div>
                <h2 className="text-xl font-black">Instalación en iPad / iPad Install</h2>
                <p className="mt-1 text-sm font-semibold leading-relaxed text-white/50">
                  Pasos para dejar Velasquez en la pantalla de inicio. / Steps to keep Velasquez on the home screen.
                </p>
              </div>
            </div>

            <div className="space-y-3">
              {installSteps.map((step, index) => (
                <div key={step.titleEs} className="rounded-2xl border border-white/10 bg-black/30 p-4">
                  <div className="mb-2 flex items-center gap-3">
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-red-600 text-sm font-black text-white shadow-lg shadow-red-600/25">
                      {index + 1}
                    </div>
                    <h3 className="text-sm font-black text-white">
                      {step.titleEs} / {step.titleEn}
                    </h3>
                  </div>
                  <p className="text-xs font-semibold leading-relaxed text-white/50">
                    {step.descriptionEs}
                  </p>
                  <p className="mt-2 text-xs font-semibold leading-relaxed text-white/35">
                    {step.descriptionEn}
                  </p>
                </div>
              ))}
            </div>
          </motion.section>
        </div>

        <motion.section
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mt-6 rounded-3xl border border-white/10 bg-white/[0.035] p-5 shadow-2xl shadow-black/30"
        >
          <div className="mb-5 flex items-start gap-3">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl border border-red-500/30 bg-red-500/15 text-red-200">
              <Wifi className="h-6 w-6" />
            </div>
            <div>
              <h2 className="text-xl font-black">Accesos rápidos / Quick Links</h2>
              <p className="mt-1 text-sm font-semibold leading-relaxed text-white/50">
                Abre o copia los enlaces que conviene guardar en la app. / Open or copy the links that are useful inside the app.
              </p>
            </div>
          </div>

          <div className="grid gap-3 md:grid-cols-3">
            {quickLinks.map((link) => (
              <div key={link.href} className="rounded-2xl border border-white/10 bg-black/30 p-4">
                <p className="text-sm font-black text-white">
                  {link.labelEs} / {link.labelEn}
                </p>
                <p className="mt-2 break-all text-xs font-semibold text-white/40">
                  {link.href}
                </p>
                <div className="mt-4 flex gap-2">
                  <a
                    href={link.href}
                    className="inline-flex flex-1 items-center justify-center gap-2 rounded-xl bg-red-600 px-3 py-2 text-xs font-black text-white shadow-lg shadow-red-600/20 transition hover:bg-red-700"
                  >
                    <ExternalLink className="h-3.5 w-3.5" />
                    Abrir
                  </a>
                  <button
                    type="button"
                    onClick={() => copyUrl(link.href)}
                    className="inline-flex flex-1 items-center justify-center gap-2 rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-xs font-black text-white/70 transition hover:border-red-500/40 hover:bg-red-500/10 hover:text-red-100"
                  >
                    <Clipboard className="h-3.5 w-3.5" />
                    {copied === link.href ? "Copiado" : "Copiar"}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </motion.section>
      </section>
    </main>
  );
}

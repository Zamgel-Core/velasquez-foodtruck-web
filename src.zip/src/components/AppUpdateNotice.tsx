// 📍 Ruta: src/components/AppUpdateNotice.tsx

import React from "react";
import { ListChecks, RefreshCw, X, Zap } from "lucide-react";
import {
  applyAppUpdate,
  checkAppVersion,
  type AppVersionInfo,
} from "../pwa/appVersion";

type Copy = {
  title: string;
  description: string;
  updateNow: string;
  later: string;
  from: string;
  to: string;
  build: string;
  changes: string;
};

function getCopy(): Copy {
  const lang = typeof window !== "undefined" ? localStorage.getItem("lang") : "es";

  if (lang === "en") {
    return {
      title: "New version available",
      description:
        "Velasquez Food Truck has an update ready. Refresh to load the latest improvements.",
      updateNow: "Update now",
      later: "Later",
      from: "Installed",
      to: "Latest",
      build: "Build",
      changes: "What's new",
    };
  }

  return {
    title: "Nueva versión disponible",
    description:
      "Velasquez Food Truck tiene una actualización lista. Actualiza para cargar las mejoras más recientes.",
    updateNow: "Actualizar ahora",
    later: "Más tarde",
    from: "Instalada",
    to: "Nueva",
    build: "Build",
    changes: "Novedades",
  };
}

export function AppUpdateNotice() {
  const [visible, setVisible] = React.useState(false);
  const [isUpdating, setIsUpdating] = React.useState(false);
  const [installed, setInstalled] = React.useState<AppVersionInfo | null>(null);
  const [current, setCurrent] = React.useState<AppVersionInfo | null>(null);

  React.useEffect(() => {
    let isMounted = true;

    async function verifyVersion() {
      try {
        const status = await checkAppVersion();

        if (!isMounted) return;

        setInstalled(status.installed);
        setCurrent(status.current);

        if (status.hasUpdate) {
          setVisible(true);
        }
      } catch (error) {
        console.warn("No se pudo verificar la versión de la app:", error);
      }
    }

    verifyVersion();

    const interval = window.setInterval(verifyVersion, 1000 * 60 * 10);

    return () => {
      isMounted = false;
      window.clearInterval(interval);
    };
  }, []);

  if (!visible || !current) return null;

  const copy = getCopy();
  const changes = current.changes ?? [];

  const handleUpdate = async () => {
    try {
      setIsUpdating(true);
      await applyAppUpdate(current);
    } catch (error) {
      console.warn("No se pudo aplicar la actualización:", error);
      window.location.reload();
    }
  };

  return (
    <div className="fixed bottom-4 left-4 right-4 z-[9999] mx-auto max-w-md rounded-3xl border border-red-500/35 bg-[#090909]/95 p-4 text-white shadow-2xl shadow-red-950/40 backdrop-blur-xl sm:left-auto sm:right-5">
      <div className="flex items-start gap-3">
        <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl border border-red-500/30 bg-red-500/15 text-red-200">
          <Zap className="h-5 w-5" />
        </div>

        <div className="min-w-0 flex-1">
          <div className="flex items-start justify-between gap-3">
            <div>
              <h2 className="text-sm font-black uppercase tracking-[0.18em] text-red-100">
                {copy.title}
              </h2>
              <p className="mt-2 text-sm font-semibold leading-relaxed text-white/65">
                {copy.description}
              </p>
            </div>

            <button
              type="button"
              onClick={() => setVisible(false)}
              className="rounded-full border border-white/10 bg-white/5 p-1.5 text-white/45 transition hover:border-red-500/40 hover:bg-red-500/10 hover:text-red-100"
              aria-label={copy.later}
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          <div className="mt-3 rounded-2xl border border-white/10 bg-black/35 p-3 text-xs font-bold text-white/45">
            <div className="flex items-center justify-between gap-3">
              <span>{copy.from}</span>
              <span>{installed?.version ?? "—"}</span>
            </div>
            <div className="mt-1 flex items-center justify-between gap-3">
              <span>{copy.build}</span>
              <span>{installed?.build ?? "—"}</span>
            </div>
            <div className="mt-2 flex items-center justify-between gap-3 border-t border-white/10 pt-2 text-red-100">
              <span>{copy.to}</span>
              <span>{current.version}</span>
            </div>
            <div className="mt-1 flex items-center justify-between gap-3 text-red-100/80">
              <span>{copy.build}</span>
              <span>{current.build}</span>
            </div>
          </div>

          {changes.length > 0 ? (
            <div className="mt-3 rounded-2xl border border-white/10 bg-black/35 p-3">
              <div className="mb-2 flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.18em] text-red-100">
                <ListChecks className="h-3.5 w-3.5" />
                {copy.changes}
              </div>
              <ul className="space-y-1 text-xs font-semibold leading-relaxed text-white/55">
                {changes.slice(0, 3).map((change) => (
                  <li key={change} className="flex gap-2">
                    <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-red-400" />
                    <span>{change}</span>
                  </li>
                ))}
              </ul>
            </div>
          ) : null}

          <div className="mt-4 flex gap-2">
            <button
              type="button"
              onClick={handleUpdate}
              disabled={isUpdating}
              className="inline-flex flex-1 items-center justify-center gap-2 rounded-2xl bg-red-600 px-4 py-3 text-sm font-black text-white shadow-lg shadow-red-600/25 transition hover:bg-red-700 disabled:cursor-not-allowed disabled:opacity-60"
            >
              <RefreshCw className={`h-4 w-4 ${isUpdating ? "animate-spin" : ""}`} />
              {copy.updateNow}
            </button>
            <button
              type="button"
              onClick={() => setVisible(false)}
              className="rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm font-black text-white/60 transition hover:border-red-500/40 hover:bg-red-500/10 hover:text-red-100"
            >
              {copy.later}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
